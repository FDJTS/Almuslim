﻿Almuslim (Windows)
------------------

Run:
  .\al-muslim.exe

Optional flags:
  --setup             First-time setup wizard
  --ask               Choose a city at launch
  --week              Show next 7 days

Notes:
- Keep the 'data' folder next to the executable.
